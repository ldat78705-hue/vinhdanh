import { useState, useEffect } from 'react';
import { CertificateBuilder } from './components/CertificateBuilder';
import { AdminPanel } from './components/AdminPanel';
import { Settings, PenTool } from 'lucide-react';
import { FONT_OPTIONS } from './lib/constants';

export default function App() {
  const [tab, setTab] = useState<'build' | 'admin'>('build');
  const [fontsLoaded, setFontsLoaded] = useState(false);

  useEffect(() => {
    document.fonts.ready.then(() => {
      setFontsLoaded(true);
    });
  }, []);

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden bg-white text-slate-900 font-sans">
      {/* Invisible font loader to ensure canvas has access to all custom fonts immediately */}
      <div style={{ position: 'absolute', opacity: 0, pointerEvents: 'none', zIndex: -100 }}>
         {FONT_OPTIONS.map(font => (
            <span key={font.value} style={{ fontFamily: font.value }}>{font.label} abc 123 á à ả ã ạ</span>
         ))}
      </div>

      <header className="h-14 sm:h-16 shrink-0 border-b border-slate-200 bg-white flex items-center px-4 sm:px-6 shadow-sm z-10 justify-between">
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="w-8 h-8 rounded bg-blue-600 flex items-center justify-center text-white font-bold text-lg">C</div>
          <h1 className="text-lg sm:text-xl font-bold text-slate-800 tracking-tight flex items-center gap-1">VinhDanh <span className="text-slate-500 font-medium hidden sm:inline">- Certificate Generator</span></h1>
        </div>

        <div className="flex bg-slate-100 p-1 rounded-lg">
          <button 
            onClick={() => setTab('build')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-1.5 rounded-md text-sm font-medium transition ${tab === 'build' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            <PenTool size={16} /> <span className="hidden sm:inline">Tạo Chứng Nhận</span>
          </button>
          <button 
            onClick={() => setTab('admin')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-1.5 rounded-md text-sm font-medium transition ${tab === 'admin' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            <Settings size={16} /> <span className="hidden sm:inline">Quản lý Mẫu</span>
          </button>
        </div>
      </header>

      <main className="flex-1 overflow-hidden relative">
        {tab === 'build' ? <CertificateBuilder /> : <AdminPanel />}
      </main>
    </div>
  );
}
