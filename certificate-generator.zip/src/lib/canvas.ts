import { TextConfig, AvatarConfig, ImageConfig } from '../types';

export const renderCertificateToCanvas = async (
  canvas: HTMLCanvasElement,
  template: { width: number; height: number; backgroundDataUrl: string; texts: Record<string, TextConfig>; avatar?: AvatarConfig; logo?: ImageConfig; signature?: ImageConfig; hiddenFields?: string[] },
  data: Record<string, string>,
  avatarDataUrl?: string
) => {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // Set physical resolution
  canvas.width = template.width;
  canvas.height = template.height;

  // 1. Draw Background
  const bgImg = new Image();
  bgImg.src = template.backgroundDataUrl;
  await new Promise<void>((resolve) => {
    bgImg.onload = () => {
      ctx.drawImage(bgImg, 0, 0, template.width, template.height);
      resolve();
    };
  });

  // Helper to draw extra images (logo, signature)
  const drawExtraImage = async (dataUrl: string | undefined, config: ImageConfig | undefined) => {
    if (!dataUrl || !config) return;
    const img = new Image();
    img.src = dataUrl;
    await new Promise<void>((resolve) => {
      img.onload = () => {
        // Calculate true height based on image aspect ratio
        const aspect = img.height / img.width;
        const renderHeight = config.width * aspect;
        
        // Center the image around x, y
        ctx.drawImage(
          img,
          config.x - config.width / 2,
          config.y - renderHeight / 2,
          config.width,
          renderHeight
        );
        resolve();
      };
      img.onerror = () => resolve(); // prevent hangs
    });
  };

  // 1.5 Draw Logo
  if (!template.hiddenFields?.includes('logo') && (data as any).showLogo !== false && (data as any).logoDataUrl) {
    const defaultLogo = template.logo || { x: template.width / 2 - 200, y: 150, width: 150, height: 150 };
    const override = (data as any).logoOverride || {};
    const logoConfig = { ...defaultLogo, ...override };
    await drawExtraImage((data as any).logoDataUrl, logoConfig);
  }

  // 2. Draw Avatar if provided
  if (!template.hiddenFields?.includes('avatar') && avatarDataUrl && template.avatar) {
    const avatar = new Image();
    avatar.src = avatarDataUrl;
    await new Promise<void>((resolve) => {
      avatar.onload = () => {
        ctx.save();
        const { x, y, radius, shape } = template.avatar!;
        
        ctx.beginPath();
        if (shape === 'circle') {
          ctx.arc(x, y, radius, 0, Math.PI * 2);
        } else {
          // rounded square trick or simple square
          ctx.rect(x - radius, y - radius, radius * 2, radius * 2);
        }
        ctx.clip();
        
        // Draw image covering the cropped area (cover behavior)
        const aspect = avatar.width / avatar.height;
        const scale = (data.avatarScale !== undefined ? parseFloat(data.avatarScale as unknown as string) : 1);
        const offsetX = (data.avatarOffsetX !== undefined ? parseFloat(data.avatarOffsetX as unknown as string) : 0);
        const offsetY = (data.avatarOffsetY !== undefined ? parseFloat(data.avatarOffsetY as unknown as string) : 0);

        let drawW = radius * 2;
        let drawH = radius * 2;
        if (aspect > 1) {
          drawW = drawH * aspect;
        } else {
          drawH = drawW / aspect;
        }

        drawW *= scale;
        drawH *= scale;

        ctx.drawImage(
          avatar, 
          x - drawW / 2 + offsetX, 
          y - drawH / 2 + offsetY, 
          drawW, 
          drawH
        );
        ctx.restore();
        resolve();
      };
    });
  }

  // 3. Draw Texts
  Object.entries(template.texts).forEach(([key, config]) => {
    // Check if it's hidden by template
    if (template.hiddenFields?.includes(key)) return;

    // Check visibility toggle (default to true if undefined)
    const visibleFields = (data as any).visibleFields || {};
    if (visibleFields[key] === false) return;

    const value = data[key];
    if (!value) return;

    const overrides = (data as any).styleOverrides?.[key] || {};
    const fontSize = overrides.fontSize || config.fontSize;
    const color = overrides.color || config.color;
    const fontFamily = overrides.fontFamily || config.fontFamily;

    ctx.font = `${config.weight} ${fontSize}px ${fontFamily}`;
    ctx.fillStyle = color;
    ctx.textAlign = config.align;
    ctx.textBaseline = 'middle';
    
    // Simple line break support if using \n
    const lines = value.split('\n');
    lines.forEach((line, index) => {
      ctx.fillText(line, config.x, config.y + (index * config.fontSize * 1.2));
    });
  });

  // 4. Draw Signature after text
  if (!template.hiddenFields?.includes('signature') && (data as any).showSignature !== false && (data as any).signatureDataUrl) {
    const defaultSig = template.signature || { x: template.width / 2 + 200, y: template.height - 150, width: 200, height: 100 };
    const override = (data as any).signatureOverride || {};
    const sigConfig = { ...defaultSig, ...override };
    await drawExtraImage((data as any).signatureDataUrl, sigConfig);
  }
};
