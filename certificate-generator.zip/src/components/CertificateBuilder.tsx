import React, { useState, useEffect, useRef } from 'react';
import { TemplateConfig, CertificateData, TextKeys, FieldStyleOverride } from '../types';
import { getTemplates, seedDefaultTemplates } from '../lib/db';
import { renderCertificateToCanvas } from '../lib/canvas';
import { resizeImageFile } from '../lib/utils';
import { FONT_OPTIONS } from '../lib/constants';
import { Download, Upload, Image as ImageIcon, Eye, EyeOff, Settings2, X } from 'lucide-react';

export const CertificateBuilder: React.FC = () => {
  const [templates, setTemplates] = useState<TemplateConfig[]>([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('');
  const [openStyleField, setOpenStyleField] = useState<TextKeys | null>(null);
  const [fontsLoaded, setFontsLoaded] = useState(false);

  useEffect(() => {
    document.fonts.ready.then(() => setFontsLoaded(true));
  }, []);

  const [data, setData] = useState<CertificateData>({
    schoolName: 'TRƯỜNG THCS LIÊN CHÂU',
    title: 'VINH DANH EM',
    studentName: 'HỌ VÀ TÊN',
    className: 'LỚP:',
    achievement: 'ĐẠT DANH HIỆU HỌC SINH GIỎI CẤP XÃ',
    date: 'Năm học: 2025 - 2026',
    principalName: '',
    avatarScale: 1,
    avatarOffsetX: 0,
    avatarOffsetY: 0,
    visibleFields: {
      schoolName: true,
      title: true,
      studentName: true,
      className: true,
      achievement: true,
      date: true,
      principalName: false
    },
    styleOverrides: {}
  });
  
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    // Load local storage settings
    const cachedSchool = localStorage.getItem('schoolName');
    const cachedPrincipal = localStorage.getItem('principalName');
    if (cachedSchool || cachedPrincipal) {
      setData(prev => ({
        ...prev,
        schoolName: cachedSchool || prev.schoolName,
        principalName: cachedPrincipal || prev.principalName
      }));
    }

    const init = async () => {
      await seedDefaultTemplates();
      const docs = await getTemplates();
      setTemplates(docs);
      if (docs.length > 0) setSelectedTemplateId(docs[0].id);
    };
    init();
  }, []);

  // Update canvas on data or template change
  useEffect(() => {
    const template = templates.find(t => t.id === selectedTemplateId);
    if (template && canvasRef.current) {
      // Cast the defined config keys correctly for the rendering function
      renderCertificateToCanvas(canvasRef.current, template, data as any, data.avatarDataUrl);
    }
  }, [data, selectedTemplateId, templates, fontsLoaded]);

  const handleDataChange = (field: keyof CertificateData, value: string) => {
    setData(prev => {
      const next = { ...prev, [field]: value };
      if (field === 'schoolName') localStorage.setItem('schoolName', value);
      if (field === 'principalName') localStorage.setItem('principalName', value);
      return next;
    });
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const dataUrl = await resizeImageFile(file, 800, 800); // 800px max for avatar
      setData(prev => ({ ...prev, avatarDataUrl: dataUrl }));
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: 'logoDataUrl' | 'signatureDataUrl') => {
    const file = e.target.files?.[0];
    if (file) {
      const dataUrl = await resizeImageFile(file, 800, 800);
      setData(prev => ({ ...prev, [field]: dataUrl }));
    }
  };

  const handleToggleVisibility = (field: TextKeys) => {
    setData(prev => ({
      ...prev,
      visibleFields: {
        ...prev.visibleFields,
        [field]: !prev.visibleFields[field]
      }
    }));
  };

  const handleAvatarSetting = (field: 'avatarScale' | 'avatarOffsetX' | 'avatarOffsetY', value: number) => {
    setData(prev => ({ ...prev, [field]: value }));
  };

  const handleStyleOverride = (field: TextKeys, prop: keyof FieldStyleOverride, value: any) => {
    setData(prev => ({
      ...prev,
      styleOverrides: {
        ...prev.styleOverrides,
        [field]: {
          ...(prev.styleOverrides?.[field] || {}),
          [prop]: value
        }
      }
    }));
  };

  const currentTemplate = templates.find(t => t.id === selectedTemplateId);

  const [draggingItem, setDraggingItem] = useState<'logo' | 'signature' | null>(null);

  const getCanvasPoint = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY
    };
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const point = getCanvasPoint(e);
    if (!point || !currentTemplate) return;

    if (data.signatureDataUrl && data.showSignature !== false) {
      const defaultSig = currentTemplate.signature || { x: currentTemplate.width / 2 + 200, y: currentTemplate.height - 150, width: 200, height: 100 };
      const override = data.signatureOverride || {};
      const config = { ...defaultSig, ...override };
      if (
        point.x >= config.x - config.width / 2 && point.x <= config.x + config.width / 2 &&
        point.y >= config.y - config.height / 2 && point.y <= config.y + config.height / 2
      ) {
        setDraggingItem('signature');
        return;
      }
    }

    if (data.logoDataUrl && data.showLogo !== false) {
      const defaultLogo = currentTemplate.logo || { x: currentTemplate.width / 2 - 200, y: 150, width: 150, height: 150 };
      const override = data.logoOverride || {};
      const config = { ...defaultLogo, ...override };
      if (
        point.x >= config.x - config.width / 2 && point.x <= config.x + config.width / 2 &&
        point.y >= config.y - config.height / 2 && point.y <= config.y + config.height / 2
      ) {
        setDraggingItem('logo');
        return;
      }
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!draggingItem) return;
    const point = getCanvasPoint(e);
    if (!point) return;

    if (draggingItem === 'logo') {
      setData(prev => ({ ...prev, logoOverride: { ...(prev.logoOverride || {}), x: point.x, y: point.y } }));
    } else if (draggingItem === 'signature') {
      setData(prev => ({ ...prev, signatureOverride: { ...(prev.signatureOverride || {}), x: point.x, y: point.y } }));
    }
  };

  const handleMouseUp = () => setDraggingItem(null);

  const handleDownload = () => {
    if (!canvasRef.current) return;
    const url = canvasRef.current.toDataURL('image/png', 1.0);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Chung-Nhan-${data.studentName.replace(/\s+/g, '-').toLowerCase() || 'Hoc-Sinh'}.png`;
    a.click();
  };

  const renderInput = (label: string, field: TextKeys, placeholder? : string, isTextArea?: boolean) => {
    if (currentTemplate?.hiddenFields?.includes(field)) return null;

    const isVisible = data.visibleFields[field];
    const isStyleOpen = openStyleField === field;
    const baseConfig = currentTemplate?.texts[field];
    const override = data.styleOverrides?.[field] || {};

    const currentFont = override.fontFamily || baseConfig?.fontFamily || 'sans-serif';
    const currentSize = override.fontSize || baseConfig?.fontSize || 40;
    const currentColor = override.color || baseConfig?.color || '#000000';

    return (
      <div className={`transition-opacity ${!isVisible ? 'opacity-50' : 'opacity-100'} bg-white border border-slate-200 rounded-xl p-3 shadow-sm mb-3`}>
        <div className="flex items-center justify-between mb-2">
          <label className="block text-sm font-semibold">{label}</label>
          <div className="flex items-center gap-1">
            <button 
              type="button"
              onClick={() => setOpenStyleField(isStyleOpen ? null : field)}
              className={`text-slate-400 hover:text-blue-600 transition p-1.5 rounded-lg ${isStyleOpen ? 'bg-blue-50 text-blue-600' : 'hover:bg-slate-100'}`}
              title="Chỉnh sửa font chữ"
              disabled={!isVisible}
            >
              <Settings2 size={16} />
            </button>
            <button 
              type="button"
              onClick={() => handleToggleVisibility(field)}
              className="text-slate-400 hover:text-blue-600 transition p-1.5 rounded-lg hover:bg-slate-100"
              title={isVisible ? "Ẩn thông tin này trên ảnh" : "Hiện thông tin này trên ảnh"}
            >
              {isVisible ? <Eye size={16} /> : <EyeOff size={16} />}
            </button>
          </div>
        </div>

        {isStyleOpen && isVisible && (
          <div className="mb-3 p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-3 relative">
            <button onClick={() => setOpenStyleField(null)} className="absolute top-2 right-2 text-slate-400 hover:text-slate-600"><X size={14}/></button>
            <div className="grid grid-cols-2 gap-2 pr-6">
              <div>
                <label className="block text-slate-500 mb-1">Font chữ</label>
                <select 
                  className="w-full border border-slate-300 rounded p-1.5 bg-white"
                  value={currentFont}
                  onChange={e => handleStyleOverride(field, 'fontFamily', e.target.value)}
                >
                  {FONT_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                </select>
              </div>
              <div className="flex gap-2">
                <div className="flex-1">
                   <label className="block text-slate-500 mb-1">Cỡ (px)</label>
                   <input type="number" className="w-full border border-slate-300 rounded p-1.5 bg-white"
                     value={currentSize} onChange={e => handleStyleOverride(field, 'fontSize', Number(e.target.value))} />
                </div>
                <div className="flex-1">
                   <label className="block text-slate-500 mb-1">Màu</label>
                   <input type="color" className="w-full border border-slate-300 rounded p-0 h-[30px] bg-white cursor-pointer"
                     value={currentColor} onChange={e => handleStyleOverride(field, 'color', e.target.value)} />
                </div>
              </div>
            </div>
          </div>
        )}

        {isTextArea ? (
          <textarea rows={2} className="w-full border-b border-slate-200 bg-slate-50 rounded-md p-2.5 outline-none transition line-clamp-3 resize-none focus:bg-white focus:ring-2 focus:ring-blue-100" 
            value={data[field]} placeholder={placeholder} onChange={e => handleDataChange(field, e.target.value)} disabled={!isVisible} />
        ) : (
          <input type="text" className="w-full border-b border-slate-200 bg-slate-50 rounded-md p-2.5 outline-none transition focus:bg-white focus:ring-2 focus:ring-blue-100" 
            placeholder={placeholder} value={data[field] as string} onChange={e => handleDataChange(field, e.target.value)} disabled={!isVisible} />
        )}
      </div>
    );
  };

  return (
    <div className="flex flex-col lg:flex-row h-full text-slate-800 overflow-hidden">
       <div className="w-full lg:w-1/3 lg:min-w-[340px] lg:max-w-[420px] border-r border-slate-200 bg-white shadow-sm overflow-y-auto flex flex-col p-4 md:p-6 shrink-0 z-10 h-[50vh] lg:h-full">
          <h2 className="text-xl font-bold mb-4 text-slate-900 border-b pb-4 sticky top-0 bg-white z-10">Tạo Chứng Nhận</h2>

           <div className="space-y-6">
              {/* Section 1: School */}
              <section className="space-y-4">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider sticky top-[60px] bg-white z-10 py-1">1. Cấu hình chung</h3>
                {renderInput('Tên Trường / Tổ chức', 'schoolName')}
                {renderInput('Người đại diện (Hiệu trưởng)', 'principalName', '', true)}
              </section>

              {/* Section 2: Template */}
              <section className="space-y-4 pt-6 border-t">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">2. Mẫu khung</h3>
                <div className="grid grid-cols-2 gap-3">
                  {templates.map(t => (
                    <div 
                      key={t.id}
                      onClick={() => {
                        setSelectedTemplateId(t.id);
                        setData(prev => ({ ...prev, styleOverrides: {} }));
                      }}
                      className={`border-2 rounded-xl overflow-hidden cursor-pointer transition ${selectedTemplateId === t.id ? 'border-blue-600 ring-2 ring-blue-100' : 'border-slate-200 hover:border-slate-300'}`}
                    >
                      <img src={t.backgroundDataUrl} alt={t.name} className="w-full h-[100px] object-cover pointer-events-none" />
                      <div className="p-2 text-xs font-medium text-center bg-slate-50 pointer-events-none">{t.name}</div>
                    </div>
                  ))}
                </div>
              </section>

              {/* Section 3: Student */}
              <section className="space-y-4 pt-6 border-t pb-10">
                 <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider sticky top-[60px] bg-white z-10 py-1">3. Thông tin vinh danh</h3>
                 
                 {!currentTemplate?.hiddenFields?.includes('avatar') && (
                 <div>
                    <label className="block text-sm font-medium mb-1 flex justify-between">
                      <span>Ảnh học sinh (Avatar)</span>
                    </label>
                    <label className="border-2 border-dashed border-slate-300 rounded-lg p-5 flex flex-col items-center justify-center cursor-pointer hover:bg-slate-50 text-slate-500 transition group relative overflow-hidden">
                      {data.avatarDataUrl ? (
                         <>
                          <img src={data.avatarDataUrl} className="absolute inset-0 w-full h-full object-contain opacity-50 blur-sm" />
                          <img src={data.avatarDataUrl} className="w-20 h-20 rounded-full border-2 border-white shadow-lg object-cover z-10" />
                          <span className="text-xs font-medium mt-2 z-10 bg-white/80 px-2 py-1 rounded shadow">Đổi ảnh khác</span>
                         </>
                      ) : (
                         <>
                           <ImageIcon size={28} className="mb-2 text-slate-400 group-hover:text-blue-500 transition" />
                           <span className="text-sm font-medium">Tới / Chọn ảnh</span>
                         </>
                      )}
                      
                      <input type="file" className="hidden" accept="image/*" onChange={handleAvatarUpload} />
                    </label>
                 </div>
                 )}

                 {!currentTemplate?.hiddenFields?.includes('avatar') && data.avatarDataUrl && (
                   <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 mt-2">
                     <p className="text-xs font-semibold mb-3 text-slate-600 flex items-center gap-2"><ImageIcon size={14} /> Chỉnh sửa ảnh thẻ</p>
                     
                     <div className="space-y-3">
                       <div className="flex items-center gap-3">
                         <label className="text-xs w-16 text-slate-500">Thu phóng</label>
                         <input type="range" min="0.1" max="3" step="0.05" value={data.avatarScale} 
                           onChange={e => handleAvatarSetting('avatarScale', parseFloat(e.target.value))} className="flex-1 accent-blue-600" />
                         <span className="text-xs w-8 text-right font-mono">{Math.round(data.avatarScale * 100)}%</span>
                       </div>
                       
                       <div className="flex items-center gap-3">
                         <label className="text-xs w-16 text-slate-500">Sang ngang</label>
                         <input type="range" min="-300" max="300" step="1" value={data.avatarOffsetX} 
                           onChange={e => handleAvatarSetting('avatarOffsetX', parseFloat(e.target.value))} className="flex-1 accent-blue-600" />
                         <button onClick={() => handleAvatarSetting('avatarOffsetX', 0)} className="text-xs text-blue-600 hover:underline w-8 text-right">Reset</button>
                       </div>
                       
                       <div className="flex items-center gap-3">
                         <label className="text-xs w-16 text-slate-500">Lên xuống</label>
                         <input type="range" min="-300" max="300" step="1" value={data.avatarOffsetY} 
                           onChange={e => handleAvatarSetting('avatarOffsetY', parseFloat(e.target.value))} className="flex-1 accent-blue-600" />
                         <button onClick={() => handleAvatarSetting('avatarOffsetY', 0)} className="text-xs text-blue-600 hover:underline w-8 text-right">Reset</button>
                       </div>
                     </div>
                   </div>
                 )}

                 <div className="grid grid-cols-2 gap-3 mt-4">
                     {currentTemplate?.hiddenFields?.includes('logo') ? <div /> : (
                     <div>
                        <label className="block text-sm font-medium mb-1 flex justify-between">
                          <span>Logo / Biểu trưng</span>
                          <div className="flex gap-2">
                            {data.logoDataUrl && (
                               <button onClick={() => setData(prev => ({ ...prev, logoDataUrl: undefined, logoOverride: undefined }))} className="text-red-400 hover:text-red-600 transition" title="Xóa Logo">
                                 <X size={16} />
                               </button>
                            )}
                            {data.logoDataUrl && (
                               <button onClick={() => setData(prev => ({ ...prev, showLogo: prev.showLogo === false ? true : false }))} className="text-slate-400 hover:text-blue-600 transition" title="Ẩn/Hiện Logo">
                                 {(data as any).showLogo === false ? <EyeOff size={16} /> : <Eye size={16} />}
                               </button>
                            )}
                          </div>
                        </label>
                        <label className="border-2 border-dashed border-slate-300 rounded-lg p-3 flex flex-col items-center justify-center cursor-pointer hover:bg-slate-50 text-slate-500 transition relative overflow-hidden h-24">
                          {data.logoDataUrl ? (
                             <>
                              <img src={data.logoDataUrl} className={`max-w-full max-h-full object-contain z-10 transition ${data.showLogo === false ? 'opacity-30' : 'opacity-100'}`} />
                             </>
                          ) : (
                             <>
                               <ImageIcon size={20} className="mb-1 text-slate-400" />
                               <span className="text-xs font-medium text-center">Tải lên Logo</span>
                             </>
                          )}
                          <input type="file" className="hidden" accept="image/*" onChange={e => handleImageUpload(e, 'logoDataUrl')} />
                        </label>
                        {data.logoDataUrl && (
                           <div className="mt-2 flex items-center gap-2">
                              <span className="text-[10px] text-slate-400">Kích thước: </span>
                              <input type="range" min="50" max="800" step="10" 
                                value={data.logoOverride?.width || currentTemplate?.logo?.width || 150}
                                onChange={e => {
                                  const val = Number(e.target.value);
                                  setData(prev => ({ 
                                    ...prev, 
                                    logoOverride: { ...(prev.logoOverride || {}), width: val } 
                                  }))
                                }}
                                className="flex-1 accent-blue-600" 
                              />
                           </div>
                        )}
                     </div>
                     )}

                     {currentTemplate?.hiddenFields?.includes('signature') ? <div /> : (
                     <div>
                        <label className="block text-sm font-medium mb-1 flex justify-between">
                          <span>Chữ ký / Mộc</span>
                          <div className="flex gap-2">
                            {data.signatureDataUrl && (
                               <button onClick={() => setData(prev => ({ ...prev, signatureDataUrl: undefined, signatureOverride: undefined }))} className="text-red-400 hover:text-red-600 transition" title="Xóa Chữ ký">
                                 <X size={16} />
                               </button>
                            )}
                            {data.signatureDataUrl && (
                               <button onClick={() => setData(prev => ({ ...prev, showSignature: prev.showSignature === false ? true : false }))} className="text-slate-400 hover:text-blue-600 transition" title="Ẩn/Hiện Chữ ký">
                                 {(data as any).showSignature === false ? <EyeOff size={16} /> : <Eye size={16} />}
                               </button>
                            )}
                          </div>
                        </label>
                        <label className="border-2 border-dashed border-slate-300 rounded-lg p-3 flex flex-col items-center justify-center cursor-pointer hover:bg-slate-50 text-slate-500 transition relative overflow-hidden h-24">
                          {data.signatureDataUrl ? (
                             <>
                              <img src={data.signatureDataUrl} className={`max-w-full max-h-full object-contain z-10 transition ${data.showSignature === false ? 'opacity-30' : 'opacity-100'}`} />
                             </>
                          ) : (
                             <>
                               <ImageIcon size={20} className="mb-1 text-slate-400" />
                               <span className="text-xs font-medium text-center">Tải lên Chữ ký</span>
                             </>
                          )}
                          <input type="file" className="hidden" accept="image/*" onChange={e => handleImageUpload(e, 'signatureDataUrl')} />
                        </label>
                        {data.signatureDataUrl && (
                           <div className="mt-2 flex items-center gap-2">
                              <span className="text-[10px] text-slate-400">Kích thước: </span>
                              <input type="range" min="50" max="800" step="10" 
                                value={data.signatureOverride?.width || currentTemplate?.signature?.width || 200}
                                onChange={e => {
                                  setData(prev => ({ 
                                    ...prev, 
                                    signatureOverride: { 
                                      ...(prev.signatureOverride || {}), 
                                      width: Number(e.target.value) 
                                    } 
                                  }))
                                }}
                                className="flex-1 accent-blue-600" 
                              />
                           </div>
                        )}
                     </div>
                     )}
                 </div>

                 {renderInput('Chủ đề vinh danh', 'title')}
                 {renderInput('Họ và tên học sinh', 'studentName', 'Ví dụ: NGUYỄN VĂN A')}
                 
                 <div className="grid grid-cols-2 gap-3">
                    {renderInput('Lớp', 'className')}
                    {renderInput('Ngày cấp', 'date')}
                 </div>

                 {renderInput('Thành tích / Nội dung', 'achievement', '', true)}
              </section>
           </div>
       </div>

       {/* Right sidebar - Live Preview */}
       <div className="flex-1 border-t lg:border-t-0 bg-slate-100 flex flex-col p-4 md:p-8 relative h-[50vh] lg:h-full overflow-hidden">
           <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 sm:mb-6 shrink-0 gap-4">
             <div>
                <h2 className="text-lg md:text-2xl font-bold text-slate-800">Live Preview</h2>
                <p className="text-slate-500 text-xs md:text-sm hidden sm:block">Hiển thị trực tiếp kết quả. Resize tự động theo màn hình.</p>
             </div>
             
             <button 
               onClick={handleDownload}
               className="bg-blue-600 hover:bg-blue-700 text-white px-4 md:px-6 py-2 md:py-3 rounded-xl font-bold shadow-lg shadow-blue-500/30 flex items-center gap-2 transition active:scale-95 w-full sm:w-auto justify-center text-sm md:text-base border border-blue-500"
             >
               <Download size={18} /> Tải Ảnh (300 DPI)
             </button>
           </div>

           <div className="flex-1 w-full bg-slate-200 border border-slate-300 shadow-inner rounded-2xl md:rounded-3xl overflow-auto flex items-center justify-center p-2 sm:p-4 md:p-8 relative">
              <div className="w-full h-full relative flex items-center justify-center">
                 <canvas 
                    ref={canvasRef} 
                    className={`max-w-full max-h-full object-contain shadow-xl md:shadow-2xl bg-white rounded-sm md:rounded-md ${draggingItem ? 'cursor-grabbing' : 'cursor-grab'}`}
                    onMouseDown={handleMouseDown}
                    onMouseMove={handleMouseMove}
                    onMouseUp={handleMouseUp}
                    onMouseLeave={handleMouseUp}
                    style={{ width: 'auto', height: 'auto', maxWidth: '100%', maxHeight: '100%' }}
                 />
              </div>
           </div>
       </div>
    </div>
  );
};
